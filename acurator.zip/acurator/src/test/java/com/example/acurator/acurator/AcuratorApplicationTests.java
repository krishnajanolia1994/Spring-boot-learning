package com.example.acurator.acurator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcuratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
